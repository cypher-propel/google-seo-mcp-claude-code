"""MCP server entrypoint — unified Google SEO suite (GSC + GA4 + cross-platform).

Tools are namespaced with prefixes to avoid collisions and aid LLM discovery:
  - `gsc_*`  for Google Search Console tools (14)
  - `ga4_*`  for Google Analytics 4 tools (14)
  - `cross_*` for cross-platform tools that use both APIs (5)
  - meta:    `get_capabilities`, `reauthenticate`
"""
from __future__ import annotations

import functools
import inspect
import logging
import os
import re
import sys
import time
import uuid
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version

import anyio
from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.exceptions import ToolError
from mcp.server.fastmcp.tools.base import Tool
from mcp.server.fastmcp.tools.tool_manager import ToolManager
from mcp.server.fastmcp.utilities.func_metadata import FuncMetadata
from mcp.server.transport_security import TransportSecuritySettings
from mcp.types import ToolAnnotations
from pydantic import ConfigDict, ValidationError, create_model

from .bing import auth as bing_auth
from .bing import tools as bing_tools
from .consumer_auth import (
    AuthenticatedConsumer, _HOSTED_AUDIT_MARKER, _audit_tool_names, _hosted_audit_message,
    consumer_context, emit_hosted_audit, request_id_context,
)
from .runtime_config import (
    ProductionRuntimeConfig,
    RuntimeConfigurationError,
    load_runtime_config,
)
from .tool_policy import ProductionToolPolicy, ToolPolicyError

_audit_log = logging.getLogger("google_seo_mcp.audit")
_ORIGINAL_LOGGER_CALL_HANDLERS = logging.Logger.callHandlers
_hosted_logging_state: dict | None = None
_hosted_audit_handler: logging.Handler | None = None


class _HostedLogFilter(logging.Filter):
    """Defense in depth for the private sink; input is never formatted here."""

    def filter(self, record: logging.LogRecord) -> bool:
        return _hosted_audit_message(record) is not None


def _guarded_call_handlers(self, record: logging.LogRecord) -> None:
    # Guard the common standard-Python delivery seam, before any library handler
    # or fallback can format the original record, regardless of propagation.
    message = _hosted_audit_message(record)
    handler = _hosted_audit_handler
    if message is not None and handler is not None:
        safe_record = logging.LogRecord(
            "google_seo_mcp.audit", logging.INFO, "", 0, message, (), None,
        )
        safe_record.__dict__["_hosted_audit_marker"] = _HOSTED_AUDIT_MARKER
        handler.handle(safe_record)


def _logger_state(logger: logging.Logger) -> tuple:
    return (logger.handlers[:], logger.level, logger.propagate, logger.disabled, logger.filters[:])


def _configure_hosted_logging() -> None:
    global _hosted_logging_state, _hosted_audit_handler
    logging._acquireLock()
    try:
        if _hosted_logging_state is not None:
            return
        loggers = [logging.root] + [
            logger for logger in logging.root.manager.loggerDict.values()
            if isinstance(logger, logging.Logger)
        ]
        _hosted_logging_state = {
            "loggers": {logger: _logger_state(logger) for logger in loggers},
            "lastResort": logging.lastResort,
        }
        handler = logging.StreamHandler(sys.stderr)
        handler.addFilter(_HostedLogFilter())
        handler.setFormatter(logging.Formatter("%(message)s"))
        _hosted_audit_handler = handler
        logging.Logger.callHandlers = _guarded_call_handlers
        logging.lastResort = logging.NullHandler()
        # Library setup may mutate these later; the delivery guard still holds.
        for logger in loggers:
            logger.handlers = []
            logger.propagate = True
        logging.root.handlers = [handler]
        logging.root.setLevel(logging.INFO)
        google_logger = logging.getLogger("google")
        google_logger.handlers = [logging.NullHandler()]
        google_logger.propagate = False
        for name in ("google_seo_mcp.audit", "google_seo_mcp.consumer_auth"):
            logger = logging.getLogger(name)
            logger.setLevel(logging.INFO)
            logger.disabled = False
            logger.filters = []
    finally:
        logging._releaseLock()


def _restore_legacy_logging() -> None:
    """Restore explicit legacy composition; simultaneous mixed servers unsupported.

    Production owns process logging until this composition boundary. Hosted-only
    loggers return to defaults; existing handlers remain open for restoration.
    """
    global _hosted_logging_state, _hosted_audit_handler
    logging._acquireLock()
    try:
        state = _hosted_logging_state
        if state is None:
            return
        logging.Logger.callHandlers = _ORIGINAL_LOGGER_CALL_HANDLERS
        logging.lastResort = state["lastResort"]
        for logger in [logging.root] + [
            item for item in logging.root.manager.loggerDict.values()
            if isinstance(item, logging.Logger)
        ]:
            saved = state["loggers"].get(logger, ([], logging.NOTSET, True, False, []))
            logger.handlers, level, logger.propagate, logger.disabled, logger.filters = saved
            logger.setLevel(level)
        if _hosted_audit_handler is not None:
            _hosted_audit_handler.close()
        _hosted_audit_handler = None
        _hosted_logging_state = None
    finally:
        logging._releaseLock()


def _safe_tool_error(exc: Exception) -> str:
    if isinstance(exc, ToolPolicyError):
        return "tool_not_allowed"
    if isinstance(exc, ValidationError):
        return "invalid_tool_arguments"
    if (type(exc) is RuntimeError and len(exc.args) == 1
            and type(exc.args[0]) is str and exc.args[0] in (
        "credentials_missing", "credentials_invalid", "vendor_unavailable",
        "google_client_unavailable", "provider_unavailable",
        "provider_not_configured", "invalid_request", "provider_error",
    )):
        return exc.args[0]
    return "provider_unavailable"


class HostedTool(Tool):
    """Own validation, execution and serialization before SDK error rendering."""

    async def run(self, arguments, context=None, convert_result=False):
        try:
            result = await self.fn_metadata.call_fn_with_arg_validation(
                self.fn, self.is_async, arguments,
                {self.context_kwarg: context} if self.context_kwarg is not None else None,
            )
            return self.fn_metadata.convert_result(result) if convert_result else result
        except Exception as exc:
            raise ToolError(_safe_tool_error(exc)) from None


class PolicyToolManager(ToolManager):
    """Enforce the same policy at registration, lookup and lowest dispatch seam."""

    def __init__(self, policy: ProductionToolPolicy):
        # Load the bundled audit names at composition, never on a tool's log
        # delivery path (which must perform no filesystem or provider access).
        _audit_tool_names()
        super().__init__(warn_on_duplicate_tools=False)
        self.policy = policy
        self.worker_limiter = anyio.CapacityLimiter(8)

    def add_tool(self, fn, name=None, **kwargs):
        tool_name = name or fn.__name__
        self.policy.enforce_tool_call(tool_name)
        if tool_name in self._tools:
            raise ToolPolicyError("tool_already_registered")

        @functools.wraps(fn)
        async def hosted_handler(*args, **arguments):
            self.policy.enforce_tool_call(tool_name)
            try:
                if inspect.iscoroutinefunction(fn):
                    return await fn(*args, **arguments)
                # AnyIO copies ContextVars into workers and bounds process-wide
                # hosted synchronous work. Cancellation waits for worker cleanup.
                return await anyio.to_thread.run_sync(
                    functools.partial(fn, *args, **arguments), limiter=self.worker_limiter,
                )
            except Exception as exc:
                raise RuntimeError(_safe_tool_error(exc)) from None

        # Resolving postponed annotations in the original module is essential:
        # wraps preserves signature text, but the wrapper has different globals.
        hosted_handler.__signature__ = inspect.signature(fn, eval_str=True)
        hosted_handler.__annotations__ = inspect.get_annotations(fn, eval_str=True)
        tool = HostedTool.from_function(hosted_handler, name=tool_name, **kwargs)
        self._tools[tool_name] = tool
        return tool

    def get_tool(self, name):
        self.policy.enforce_tool_call(name)
        return super().get_tool(name)

    def list_tools(self):
        return [tool for tool in super().list_tools() if self.policy.is_tool_allowed(tool.name)]

    async def call_tool(self, name, arguments, context=None, convert_result=False):
        started, outcome = time.monotonic(), "error"
        safe_name = name if self.policy.is_tool_allowed(name) else "denied"
        try:
            self.policy.enforce_tool_call(name, context)
            tool = self.get_tool(name)
            if tool is None:
                raise ToolPolicyError("tool_not_allowed")
            result = await tool.run(arguments, context=context, convert_result=convert_result)
            outcome = "success"
            return result
        except Exception as exc:
            outcome = "denied" if isinstance(exc, ToolPolicyError) else "error"
            # HostedTool already sanitized SDK validation/provider failures.
            code = str(exc) if type(exc) is ToolError and str(exc) in (
                "credentials_missing", "credentials_invalid", "vendor_unavailable",
                "google_client_unavailable", "provider_unavailable", "invalid_tool_arguments",
                "tool_not_allowed",
                "provider_not_configured", "invalid_request", "provider_error",
            ) else _safe_tool_error(exc)
            raise ToolError(code) from None
        finally:
            consumer = consumer_context.get()
            request_id = request_id_context.get()
            if not isinstance(request_id, str) or re.fullmatch(r"[0-9a-f]{32}", request_id) is None:
                request_id = uuid.uuid4().hex
            emit_hosted_audit(_audit_log, {
                "request_id": request_id,
                "consumer": (
                    consumer.consumer_id if isinstance(consumer, AuthenticatedConsumer) else None
                ),
                "tool": safe_name, "outcome": outcome,
                "duration_ms": round((time.monotonic() - started) * 1000, 3),
            })


class ProductionFastMCP(FastMCP):
    def __init__(self, config: ProductionRuntimeConfig):
        if not isinstance(config, ProductionRuntimeConfig) or config.profile != "production":
            raise ToolPolicyError("invalid production configuration")
        auth_module.configure_hosted_auth(config)
        _configure_hosted_logging()
        self.runtime_config = config
        self.production_policy = ProductionToolPolicy()
        super().__init__(
            "google-seo-mcp", host=config.host, port=config.port,
            stateless_http=True, json_response=True, streamable_http_path="/mcp",
            transport_security=TransportSecuritySettings(
                enable_dns_rebinding_protection=True,
                allowed_hosts=list(config.accepted_hosts),
                allowed_origins=list(config.accepted_origins),
            ),
        )
        self._tool_manager = PolicyToolManager(self.production_policy)


def _resolve_mcp_version() -> str:
    """Returns the installed `google-seo-mcp` package version, or 'unknown'.

    Used by `get_capabilities` so the operator can verify which version
    the MCP process actually loaded into memory — independent of what
    `pip show` reports (which only reflects metadata at install time
    and lies for editable installs after a code update without reinstall).
    """
    try:
        return _pkg_version("google-seo-mcp")
    except PackageNotFoundError:
        return "unknown (not installed as a package)"


# Mapping from tool-name prefix to category. Order matters — first match wins,
# so list the more specific prefixes BEFORE shorter ones that would otherwise
# capture them.
_CATEGORY_RULES: list[tuple[str, str]] = [
    # Cross-platform first (otherwise gsc_/ga4_ would never see them)
    ("cross_", "cross_platform"),
    # GSC
    ("gsc_", "gsc"),
    # GA4
    ("ga4_", "ga4"),
    ("bing_", "bing"),
    # Performance
    ("lighthouse_", "lighthouse"),
    ("crux_", "crux"),
    # Schema
    ("schema_", "schema"),
    # Indexing — both indexnow_* and google_indexing_*
    ("indexnow_", "indexing"),
    ("google_indexing_", "indexing"),
    # Trends / Suggest / Alerts
    ("google_trends_", "trends"),
    ("google_suggest", "trends"),
    ("alerts_", "trends"),
    # Migration
    ("migration_", "migration"),
    # AEO
    ("aeo_", "aeo"),
    # v0.8.0 modules
    ("history_", "history"),
    ("serp_", "serp"),
    ("logs_", "logs"),
    # Meta — leave a 'meta' bucket for everything else (get_capabilities,
    # reload_credentials, reauthenticate)
]


def _categorize_registered_tools() -> dict[str, list[str]]:
    """Group the actually-registered tools by category, derived from the name
    prefix (NOT a hardcoded list).

    Eliminates the historical drift between what's registered and what
    `get_capabilities` advertises. If a future contributor registers a tool
    whose prefix isn't in `_CATEGORY_RULES`, it lands in `meta` so the
    operator still sees it — and can file a PR to add the rule.
    """
    categories: dict[str, list[str]] = {}
    for tool in mcp._tool_manager.list_tools():
        name = tool.name
        bucket = "meta"
        for prefix, label in _CATEGORY_RULES:
            if name.startswith(prefix):
                bucket = label
                break
        categories.setdefault(bucket, []).append(name)
    # Sort each bucket alphabetically for stable output across calls.
    return {k: sorted(v) for k, v in sorted(categories.items())}

from . import auth as auth_module
from .crossplatform import attribution as cp_attr
from .crossplatform import diagnosis as cp_diag
from .crossplatform import health as cp_health
from .crossplatform import journey as cp_journey
from .crossplatform import matrix as cp_matrix
from .crossplatform import multi_property as cp_multi
from .crux import tools as crux_tools
from .ga4.tools import admin as ga4_admin
from .ga4.tools import intelligence as ga4_intel
from .ga4.tools import reporting as ga4_reporting
from .gsc.tools import analytics as gsc_analytics
from .gsc.tools import intelligence as gsc_intel
from .gsc.tools import sitemaps as gsc_sitemaps
from .gsc.tools import sites as gsc_sites
from .history import tools as history_tools
from .indexing import tools as indexing_tools
from .lighthouse import tools as lh_tools
from .logs import tools as logs_tools
from .migration import crawl_advanced as migration_crawl_advanced
from .migration import tools as migration_tools
from .schema import tools as schema_tools
from .serp import tools as serp_tools
from .trends import tools as trends_tools
from .guardrails import GUARDRAIL_SUFFIX
from .resources.google_algorithm_updates import algorithm_updates_text

# MCP servers communicate JSON-RPC over stdout. ANY library log line that
# slips to stdout corrupts the protocol and the agent stops receiving
# tool results. We force every logger (ours and third-party) to stderr,
# and use ``force=True`` in case a library imported earlier already
# attached a handler to the root logger.
def _bootstrap_log_level() -> int:
    # Never pass raw configuration into logging: its ValueError echoes unknown
    # levels, before main() can apply the sanitized runtime boundary.
    levels = {
        "CRITICAL": logging.CRITICAL,
        "FATAL": logging.FATAL,
        "ERROR": logging.ERROR,
        "WARNING": logging.WARNING,
        "WARN": logging.WARN,
        "INFO": logging.INFO,
        "DEBUG": logging.DEBUG,
        "NOTSET": logging.NOTSET,
    }
    level = levels.get(os.getenv("GOOGLE_SEO_LOG_LEVEL", "INFO"))
    if level is None:
        raise RuntimeConfigurationError("invalid runtime configuration") from None
    return level


_BOOTSTRAP_LOG_LEVEL = _bootstrap_log_level()

mcp = FastMCP("google-seo-mcp")


def _register(fn, *, name: str):
    """Register a tool with a specific name and append the guardrail suffix.

    Idempotent: detects whether the suffix has already been appended (so registering
    the same function twice doesn't duplicate the suffix).
    """
    base_doc = (fn.__doc__ or "").rstrip()
    if not base_doc.endswith(GUARDRAIL_SUFFIX.rstrip()):
        fn.__doc__ = base_doc + GUARDRAIL_SUFFIX
    return mcp.tool(name=name)(fn)


class _BingFuncMetadata(FuncMetadata):
    """Keep original scalar values for strict Bing-only SDK validation.

    The SDK normally JSON-decodes e.g. limit="100" before validation. Incumbent
    tools retain their original models and pre-parser/coercion behavior.
    """

    def pre_parse_json(self, data):
        return data


def _register_bing(manager: ToolManager, fn, *, name: str) -> None:
    """Install Bing-only schema, error boundary and annotations in any registry."""
    base_doc = (fn.__doc__ or "").rstrip()
    if not base_doc.endswith(GUARDRAIL_SUFFIX.rstrip()):
        fn.__doc__ = base_doc + GUARDRAIL_SUFFIX
    tool = manager.add_tool(fn, name=name, annotations=ToolAnnotations(
        readOnlyHint=True, destructiveHint=False, openWorldHint=False,
    ))
    metadata = tool.fn_metadata
    argument_model = create_model(
        f"{name}StrictArguments", __base__=metadata.arg_model,
        __config__=ConfigDict(strict=True, extra="forbid"),
    )
    tool.fn_metadata = _BingFuncMetadata(
        arg_model=argument_model, output_schema=metadata.output_schema,
        output_model=metadata.output_model, wrap_output=metadata.wrap_output,
    )
    tool.parameters = argument_model.model_json_schema(by_alias=True)
    # Legacy SDK Tool.run includes exception values. Use safe execution for Bing
    # in legacy mode too, without replacing any incumbent tool or its metadata.
    if not isinstance(tool, HostedTool):
        tool = HostedTool(**{
            field: getattr(tool, field) for field in Tool.model_fields
        })
        manager._tools[name] = tool


# Exact eleven reads, registered before legacy capture and reused for rebuilds.
# No configure/reset seam or aliases are admitted.
_BING_TOOL_DEFINITIONS = (
    (bing_tools.bing_list_sites, "bing_list_sites"),
    (bing_tools.bing_rank_traffic_stats, "bing_rank_traffic_stats"),
    (bing_tools.bing_query_stats, "bing_query_stats"),
    (bing_tools.bing_page_stats, "bing_page_stats"),
    (bing_tools.bing_page_query_stats, "bing_page_query_stats"),
    (bing_tools.bing_query_page_stats, "bing_query_page_stats"),
    (bing_tools.bing_crawl_stats, "bing_crawl_stats"),
    (bing_tools.bing_crawl_issues, "bing_crawl_issues"),
    (bing_tools.bing_url_info, "bing_url_info"),
    (bing_tools.bing_list_sitemaps, "bing_list_sitemaps"),
    (bing_tools.bing_sitemap_details, "bing_sitemap_details"),
)
_BING_TOOL_NAMES = frozenset(name for _, name in _BING_TOOL_DEFINITIONS)
for _bing_fn, _bing_name in _BING_TOOL_DEFINITIONS:
    _register_bing(mcp._tool_manager, _bing_fn, name=_bing_name)


# ─── GSC: sites & inspection ─────────────────────────────────
_register(gsc_sites.list_sites, name="gsc_list_sites")
_register(gsc_sites.inspect_url, name="gsc_inspect_url")

# ─── GSC: sitemaps ───────────────────────────────────────────
_register(gsc_sitemaps.list_sitemaps, name="gsc_list_sitemaps")
_register(gsc_sitemaps.submit_sitemap, name="gsc_submit_sitemap")

# ─── GSC: analytics ──────────────────────────────────────────
_register(gsc_analytics.search_analytics, name="gsc_search_analytics")
_register(gsc_analytics.site_snapshot, name="gsc_site_snapshot")

# ─── GSC: intelligence ───────────────────────────────────────
_register(gsc_intel.quick_wins, name="gsc_quick_wins")
_register(gsc_intel.traffic_drops, name="gsc_traffic_drops")
_register(gsc_intel.content_decay, name="gsc_content_decay")
_register(gsc_intel.cannibalization, name="gsc_cannibalization")
_register(gsc_intel.ctr_opportunities, name="gsc_ctr_opportunities")
_register(gsc_intel.alerts, name="gsc_alerts")

# ─── GA4: admin ──────────────────────────────────────────────
_register(ga4_admin.list_properties, name="ga4_list_properties")
_register(ga4_admin.get_property_details, name="ga4_get_property_details")

# ─── GA4: schema & reporting ─────────────────────────────────
_register(ga4_reporting.search_ga4_schema, name="ga4_search_schema")
_register(ga4_reporting.list_schema_categories, name="ga4_list_schema_categories")
_register(ga4_reporting.estimate_query_size, name="ga4_estimate_query_size")
_register(ga4_reporting.query_ga4, name="ga4_query")

# ─── GA4: intelligence ───────────────────────────────────────
_register(ga4_intel.anomalies, name="ga4_anomalies")
_register(ga4_intel.traffic_drops_by_channel, name="ga4_traffic_drops_by_channel")
_register(ga4_intel.landing_page_health, name="ga4_landing_page_health")
_register(ga4_intel.conversion_funnel, name="ga4_conversion_funnel")
_register(ga4_intel.event_volume_comparison, name="ga4_event_volume_comparison")
_register(ga4_intel.cohort_retention, name="ga4_cohort_retention")
_register(ga4_intel.channel_attribution, name="ga4_channel_attribution")
_register(ga4_intel.content_decay, name="ga4_content_decay")

# ─── Cross-platform (the killer features) ────────────────────
_register(cp_journey.gsc_to_ga4_journey, name="cross_gsc_to_ga4_journey")
_register(cp_health.traffic_health_check, name="cross_traffic_health_check")
_register(cp_matrix.opportunity_matrix, name="cross_opportunity_matrix")
_register(cp_attr.seo_to_revenue_attribution, name="cross_seo_to_revenue_attribution")
_register(cp_diag.landing_page_full_diagnosis, name="cross_landing_page_full_diagnosis")
_register(cp_multi.multi_property_comparison, name="cross_multi_property_comparison")

# ─── Lighthouse / PageSpeed Insights (5) ────────────────────
_register(lh_tools.lighthouse_audit, name="lighthouse_audit")
_register(lh_tools.lighthouse_core_web_vitals, name="lighthouse_core_web_vitals")
_register(lh_tools.lighthouse_lcp_opportunities, name="lighthouse_lcp_opportunities")
_register(lh_tools.lighthouse_compare_mobile_desktop, name="lighthouse_compare_mobile_desktop")
_register(lh_tools.lighthouse_seo_score, name="lighthouse_seo_score")

# ─── Chrome UX Report (real-user CWV) (3) ───────────────────
_register(crux_tools.crux_current, name="crux_current")
_register(crux_tools.crux_history, name="crux_history")
_register(crux_tools.crux_compare_origins, name="crux_compare_origins")

# ─── Schema.org / structured data (3) ───────────────────────
_register(schema_tools.schema_extract_url, name="schema_extract_url")
_register(schema_tools.schema_validate_url, name="schema_validate_url")
_register(schema_tools.schema_suggest_for_page, name="schema_suggest_for_page")

# ─── Sitemap submission / Indexing (5) ──────────────────────
_register(indexing_tools.indexnow_generate_key, name="indexnow_generate_key")
_register(indexing_tools.indexnow_submit, name="indexnow_submit")
_register(indexing_tools.indexnow_submit_sitemap, name="indexnow_submit_sitemap")
_register(indexing_tools.google_indexing_publish, name="google_indexing_publish")
_register(indexing_tools.google_indexing_delete, name="google_indexing_delete")

# ─── Trends / Suggest / Alerts (5) ───────────────────────────
_register(trends_tools.google_suggest, name="google_suggest")
_register(trends_tools.google_suggest_alphabet, name="google_suggest_alphabet")
_register(trends_tools.google_trends_keyword, name="google_trends_keyword")
_register(trends_tools.google_trends_related, name="google_trends_related")
_register(trends_tools.alerts_rss_parse, name="alerts_rss_parse")

# ─── Migration: WP equity + SSR verify + sitemap diff (14) ───
_register(migration_tools.wp_audit_site, name="migration_wp_audit_site")
_register(migration_tools.wp_extract_redirects, name="migration_wp_extract_redirects")
_register(migration_tools.wp_internal_links_graph, name="migration_wp_internal_links_graph")
_register(migration_tools.prerender_check, name="migration_prerender_check")
_register(migration_tools.prerender_check_batch, name="migration_prerender_check_batch")
_register(migration_tools.calibration_check, name="migration_calibration_check")
_register(migration_tools.meta_validate_golden_set, name="migration_meta_validate_golden_set")
_register(migration_tools.prerender_vs_hydrated, name="migration_prerender_vs_hydrated")
_register(migration_tools.googlebot_diff, name="migration_googlebot_diff")
_register(migration_tools.multi_bot_diff, name="migration_multi_bot_diff")
_register(migration_tools.verify_googlebot_ip, name="migration_verify_googlebot_ip")
_register(migration_tools.sitemap_diff, name="migration_sitemap_diff")
_register(migration_tools.sitemap_validate, name="migration_sitemap_validate")
_register(migration_tools.migration_redirects_plan, name="migration_redirects_plan")
_register(migration_tools.export_redirects_nginx, name="migration_export_redirects_nginx")
_register(migration_tools.export_redirects_apache, name="migration_export_redirects_apache")
_register(migration_tools.export_redirects_cloudflare, name="migration_export_redirects_cloudflare")
_register(migration_tools.seo_equity_report, name="migration_seo_equity_report")
_register(migration_tools.wayback_baseline, name="migration_wayback_baseline")
_register(migration_tools.schema_parity_check, name="migration_schema_parity_check")
_register(migration_tools.hreflang_cluster_audit, name="migration_hreflang_cluster_audit")
_register(migration_tools.indexation_recovery_monitor, name="migration_indexation_recovery_monitor")

# v0.7.0 — robots.txt audit + diff (Crawl Budget review)
from .migration import robots_audit as _robots_audit  # noqa: E402

def _robots_audit_tool(origin_url: str, sample_paths: list[str] | None = None) -> dict:
    """Audit robots.txt: sitemaps declared, crawl-delay, disallows, sample-path verdicts."""
    from .guardrails import with_meta
    return with_meta(
        _robots_audit.robots_audit(origin_url, sample_paths=sample_paths),
        source="migration.robots_audit", site_url=origin_url,
    )


def _robots_diff_tool(
    old_origin_url: str, new_origin_url: str,
    paths_to_check: list[str], user_agent: str = "Googlebot",
) -> dict:
    """Diff old vs new robots.txt for a set of ranked paths.

    Pass paths_to_check from `gsc_search_analytics(dimensions=['page'])` —
    URLs that already drive clicks. Anything `newly_blocked` is critical:
    you'll lose those clicks the day Google reads the new robots.txt.
    """
    from .guardrails import with_meta
    return with_meta(
        _robots_audit.robots_diff(
            old_origin_url, new_origin_url, paths_to_check, user_agent=user_agent,
        ),
        source="migration.robots_diff",
    )

_register(_robots_audit_tool, name="migration_robots_audit")
_register(_robots_diff_tool, name="migration_robots_diff")

# v0.7.0 — AEO foundation (Answer Engine Optimization)
from .aeo import llms_txt as _llms_txt_mod  # noqa: E402
from .aeo import ai_bots_robots as _ai_bots_mod  # noqa: E402

def _llms_txt_check(origin_url: str) -> dict:
    """Verify ``/llms.txt`` and ``/llms-full.txt`` (LLM-discoverable index).

    The llmstxt.org convention lets a site declare what an LLM should
    ingest. Anthropic, Vercel, Cloudflare and most modern docs sites
    publish it. Returns presence + parsed structure + lint warnings.
    """
    from .guardrails import with_meta
    return with_meta(
        _llms_txt_mod.llms_txt_check(origin_url),
        source="aeo.llms_txt_check", site_url=origin_url,
    )


def _ai_bots_robots(origin_url: str, sample_path: str = "/") -> dict:
    """Audit how every major AI/LLM crawler is treated by robots.txt.

    Reports per-bot allow/block (GPTBot, ClaudeBot, PerplexityBot,
    Google-Extended, CCBot, Bytespider, etc.) plus a vendor + purpose +
    docs URL so the agent can flag accidental blocks or accidental allows.
    """
    from .guardrails import with_meta
    return with_meta(
        _ai_bots_mod.aibots_robots_audit(origin_url, sample_path=sample_path),
        source="aeo.aibots_robots_audit", site_url=origin_url,
    )

_register(_llms_txt_check, name="aeo_llms_txt_check")
_register(_ai_bots_robots, name="aeo_ai_bots_robots_audit")

# v0.8.0 — Persistence (history/), SERP intelligence (DataForSEO),
# server log analysis, advanced technical crawl
_register(history_tools.history_save_snapshot, name="history_save_snapshot")
_register(history_tools.history_diff,          name="history_diff")
_register(history_tools.history_list,          name="history_list")

_register(serp_tools.serp_check,                name="serp_check")
_register(serp_tools.serp_aio_monitor,          name="serp_aio_monitor")
_register(serp_tools.serp_paa_extractor,        name="serp_paa_extractor")
_register(serp_tools.serp_competitor_intersect, name="serp_competitor_intersect")

_register(logs_tools.logs_parse,                  name="logs_parse")
_register(logs_tools.logs_googlebot_crawl_budget, name="logs_googlebot_crawl_budget")
_register(logs_tools.logs_bot_ratio,              name="logs_bot_ratio")
_register(logs_tools.logs_spider_trap_detector,   name="logs_spider_trap_detector")
_register(logs_tools.logs_crawl_waste,            name="logs_crawl_waste")
_register(logs_tools.logs_status_distribution,    name="logs_status_distribution")
_register(logs_tools.logs_verify_googlebot_ip,    name="logs_verify_googlebot_ip")

_register(migration_crawl_advanced.crawl_redirect_chains,        name="migration_redirect_chains")
_register(migration_crawl_advanced.check_broken_internal_links,  name="migration_broken_internal_links")
_register(migration_crawl_advanced.measure_response_times,       name="migration_response_times")
_register(migration_crawl_advanced.check_image_alt_coverage,     name="migration_image_alt_coverage")


# Singular convenience wrappers — same logic, single-URL input, friendlier
# return shape. Several internal docs and external prompts referenced these
# names before the plural ones were finalized; keeping both avoids breaking
# anyone's existing playbook.
def _migration_redirect_chain(url: str, max_hops: int = 10, timeout: float = 15.0) -> dict:
    """Trace the full 301/302 chain for a SINGLE URL.

    Returns the chain (list of {url, status, location}), final URL, hop count,
    and a flag if it exceeds Googlebot's drop threshold (5 hops).
    Use ``migration_redirect_chains`` for batched lookups over a URL list.
    """
    result = migration_crawl_advanced.crawl_redirect_chains(
        [url], max_hops=max_hops, timeout=timeout,
    )
    data = result.get("data") if isinstance(result, dict) and "data" in result else result
    chains = (data or {}).get("results", []) if isinstance(data, dict) else []
    single = chains[0] if chains else {"url": url, "error": "empty_result"}
    return {**result, "data": single} if isinstance(result, dict) and "_meta" in result else single


def _migration_image_alts(url: str, timeout: float = 15.0) -> dict:
    """Check ``<img alt>`` coverage for a SINGLE URL.

    Returns counts of images with/without alt, coverage_pct, and a sample of
    the missing-alt URLs. Use ``migration_image_alt_coverage`` for a batch over
    a list of pages.
    """
    result = migration_crawl_advanced.check_image_alt_coverage(
        [url], timeout=timeout,
    )
    data = result.get("data") if isinstance(result, dict) and "data" in result else result
    pages = (data or {}).get("page_results", []) if isinstance(data, dict) else []
    single = pages[0] if pages else {"page": url, "error": "empty_result"}
    return {**result, "data": single} if isinstance(result, dict) and "_meta" in result else single


_register(_migration_redirect_chain, name="migration_redirect_chain")
_register(_migration_image_alts,     name="migration_image_alts")


# ─── MCP Resource: Google algorithm updates reference ────────
@mcp.resource("google-seo://algorithm-updates")
def google_algorithm_updates_resource() -> str:
    """Reference list of confirmed Google Search algorithm updates (2023–2026).

    Use this resource when investigating traffic drops to correlate with industry-wide
    events. A drop on a core-update rollout day is much more likely Google-driven
    than site-specific.
    """
    return algorithm_updates_text()


@mcp.tool()
def reload_credentials() -> dict:
    """Reset in-process auth clients and reload credentials on next call.

    Use this when:
      - You rotated the Service Account JSON file (GOOGLE_SEO_SERVICE_ACCOUNT_FILE).
      - You ran `gcloud auth application-default login` and need the MCP to pick
        up the new ADC.
      - Tools are returning data from the previous client / tenant after switching.
      - The cached OAuth token is stale and you want a fresh consent flow.

    The response includes `credential_type` ('service_account' / 'adc' /
    'oauth_flow' / 'none') so you know which method will be used on the next
    call. Service Account credentials are self-issued JWTs — no real "re-auth"
    happens, just a cache reset and JSON reload from disk. ADC and OAuth flow
    do re-validate against Google.
    """
    return auth_module.reset_clients()


@mcp.tool()
def reauthenticate() -> dict:
    """Deprecated alias for `reload_credentials`. Kept for backward compatibility.

    Was misleading when the active credential is a Service Account (JWT-based,
    no re-auth handshake exists). Use `reload_credentials` going forward.
    """
    return auth_module.reset_clients()


@mcp.tool()
def get_capabilities() -> dict:
    """List all tools exposed by this MCP and current auth status. Call FIRST.

    Returns the tool catalog grouped by category, plus a quick check of whether
    credentials are reachable for both Google Search Console and Google Analytics 4.

    Also returns `mcp_version` and `credential_type` so the operator can verify
    which version is actually loaded in memory and which auth method is active —
    independent of what external tooling (pip show, env files) reports.
    """
    gsc_ok = True
    ga4_ok = True
    gsc_err: str | None = None
    ga4_err: str | None = None
    try:
        auth_module.get_webmasters().sites().list().execute()
    except Exception as e:
        gsc_ok = False
        gsc_err = str(e)[:200]
    try:
        admin = auth_module.get_admin_client()
        next(iter(admin.list_account_summaries()), None)
    except Exception as e:
        ga4_ok = False
        ga4_err = str(e)[:200]

    # Categories derived DYNAMICALLY from the actual registered tools so the
    # output never drifts from reality. The previous hardcoded dict went stale
    # across versions and made entire modules (AEO, history, serp, logs,
    # advanced crawl) invisible to agents that used `get_capabilities` as the
    # source of truth for tool discovery. Lesson learned.
    categories = _categorize_registered_tools()

    # Optional-dependency probe — surfaces tools that are registered but
    # would fail at invocation time because their dep is missing (typically
    # Playwright for `migration_prerender_vs_hydrated`). The agent can read
    # `tools_unavailable[*].affected_tools` BEFORE invoking, plan around it,
    # and ask the human to install if needed — instead of discovering the
    # gap mid-audit.
    from . import _dep_check
    deps = _dep_check.probe_optional_deps()
    tools_unavailable = []
    for missing in deps["unavailable"]:
        if missing["degraded_not_broken"]:
            continue  # tool still works, just on a fallback path — don't list as unavailable
        for tool_name in missing["affected_tools"]:
            tools_unavailable.append({
                "name": tool_name,
                "reason": missing["reason"],
                "install_cmd": missing["install_cmd"],
                "extra_cmd": missing.get("extra_cmd"),
            })

    return {
        "mcp_version": _resolve_mcp_version(),
        "auth": {
            "gsc": {"ok": gsc_ok, "error": gsc_err},
            "ga4": {"ok": ga4_ok, "error": ga4_err},
            "credential_type": auth_module.current_credential_type(),
            "destructive_enabled": os.getenv("GSC_ALLOW_DESTRUCTIVE") == "true",
        },
        "tools_total": sum(len(v) for v in categories.values() if isinstance(v, list)),
        "categories": categories,
        "tools_unavailable": tools_unavailable,
        "deps": deps,
        "resources": ["google-seo://algorithm-updates"],
        "tip": (
            "Swiss-knife workflow: (1) `gsc_list_sites` + `ga4_list_properties` to "
            "enumerate. (2) `cross_traffic_health_check` to verify tracking. "
            "(3) `lighthouse_audit` + `crux_current` for performance health. "
            "(4) `cross_opportunity_matrix` for prioritisation. (5) `schema_validate_url` "
            "to find rich-result gaps. (6) `google_suggest_alphabet` to discover "
            "long-tails. (7) `indexnow_submit` to ping Bing/Yandex on changes."
        ),
    }


# Capture callable definitions once, before any transport selection. A later CLI
# override rebuilds its own manager and never reuses the legacy 113-tool manager.
_LEGACY_TOOL_DEFINITIONS = tuple((tool.fn, tool.name) for tool in mcp._tool_manager.list_tools())

# Initial catalog construction is transport-neutral: do not enable SDK debug
# output before the selected server can install its hosted audit-only filter.
# Legacy imports and stdio still receive their validated level on stderr.
logging.basicConfig(
    level=_BOOTSTRAP_LOG_LEVEL,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    stream=sys.stderr,
    force=True,
)


def create_server(config: ProductionRuntimeConfig) -> FastMCP:
    """Create the selected registry without credential construction or refresh.

    HTTP composition calls create_http_app(config, registry, create_server(config)).
    Independent stdio/HTTP processes are the supported lifecycle; auth identity is
    process-wide and intentionally shared by all hosted consumers.
    """
    bing_auth.configure_bing_auth(config)
    bing_tools.configure_bing_tools()
    if config.profile == "production":
        instance = ProductionFastMCP(config)
        for fn, name in _LEGACY_TOOL_DEFINITIONS:
            if instance.production_policy.is_tool_allowed(name):
                if name in _BING_TOOL_NAMES:
                    _register_bing(instance._tool_manager, fn, name=name)
                else:
                    instance.add_tool(fn, name=name)
        registered = {tool.name for tool in instance._tool_manager.list_tools()}
        if registered != instance.production_policy.names:
            raise ToolPolicyError("production tool registry mismatch")
    else:
        _restore_legacy_logging()
        auth_module.configure_hosted_auth(config)
        instance = FastMCP("google-seo-mcp")
        for fn, name in _LEGACY_TOOL_DEFINITIONS:
            if name in _BING_TOOL_NAMES:
                _register_bing(instance._tool_manager, fn, name=name)
            else:
                instance.add_tool(fn, name=name)
    instance.resource("google-seo://algorithm-updates")(google_algorithm_updates_resource)
    return instance


def main(argv: list[str] | None = None) -> None:
    config = load_runtime_config(argv)
    instance = create_server(config)
    if config.transport == "stdio":
        instance.run(transport="stdio")
        return
    import uvicorn

    from .consumer_auth import load_consumer_key_registry
    from .http_app import create_http_app

    registry = load_consumer_key_registry(config.consumer_keys_file)
    application = create_http_app(config, registry, instance)
    uvicorn.run(application, host=config.host, port=config.port,
                access_log=False, proxy_headers=False, log_config=None)


if __name__ == "__main__":
    main()
