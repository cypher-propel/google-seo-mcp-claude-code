"""Unified authentication for Google Search Console + Google Analytics 4.

Single entry point that requests BOTH scopes (`webmasters.readonly` +
`analytics.readonly`) and builds clients for:
  - Webmasters API v3 (GSC search analytics, sitemaps, sites)
  - Search Console API v1 (URL Inspection)
  - GA4 Admin API v1beta (account/property listing)
  - GA4 Data API v1beta (run_report, run_realtime_report)

Resolution order:
  1. ADC — `GOOGLE_APPLICATION_CREDENTIALS` env or default `gcloud` ADC file.
  2. Service account — `GOOGLE_SEO_SERVICE_ACCOUNT_FILE`.
  3. OAuth user flow — `GOOGLE_SEO_OAUTH_CLIENT_FILE` (Desktop client JSON).
"""
from __future__ import annotations

import json
import logging
import os
import tempfile
import threading
from pathlib import Path
from typing import Any

from google.analytics.admin_v1beta import AnalyticsAdminServiceClient
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.auth import default as google_auth_default
from google.auth.crypt import RSASigner
from google.auth.exceptions import RefreshError
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google.oauth2.service_account import Credentials as SACredentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from platformdirs import user_config_dir

log = logging.getLogger(__name__)

# Singleton client cache is mutated lazily across tool calls. FastMCP runs
# tool handlers concurrently in worker threads; without this lock two
# parallel calls can both pass the ``is None`` check and run a fresh OAuth
# flow simultaneously (two browser tabs, racy ``token.json`` writes).
_auth_lock = threading.Lock()

# Read scopes only — destructive ops are gated by env flag, requested only when set.
SCOPES_READ = [
    "https://www.googleapis.com/auth/webmasters.readonly",
    "https://www.googleapis.com/auth/analytics.readonly",
]
SCOPES_WRITE = [
    "https://www.googleapis.com/auth/webmasters",
    "https://www.googleapis.com/auth/analytics.readonly",
]

_searchconsole_service: Any = None
_webmasters_service: Any = None
_ga4_data_client: Any = None
_ga4_admin_client: Any = None

# Identity fingerprint of the credentials currently held in the singletons.
# Recomputed on every getter: when the operator runs ``gcloud auth
# application-default login`` with a different account (or rotates
# GOOGLE_APPLICATION_CREDENTIALS / GOOGLE_SEO_SERVICE_ACCOUNT_FILE), the
# fingerprint changes and we transparently rebuild the clients — without
# this, all tools silently keep returning data from the previous account.
_credentials_fingerprint: str | None = None

# Set only by the composition root after validating the runtime boundary.  A
# hosted process never consults the legacy credential cascade or developer HOME.
_hosted_auth_enabled = False
_hosted_service_account_file: Path | None = None
_hosted_credentials: Any = None
_hosted_credentials_invalid = False
_hosted_file_fingerprint: tuple[int, ...] | None = None
_hosted_file_valid = False


def is_hosted_production() -> bool:
    """Also fail closed for direct helper use before composition is complete."""
    return _hosted_auth_enabled or os.getenv("GOOGLE_SEO_PROFILE", "").lower() == "production"


def hosted_auth_enabled() -> bool:
    """Whether the composition root captured a validated hosted identity."""
    return _hosted_auth_enabled


def configure_hosted_auth(config: Any) -> None:
    """Select the validated identity without opening files or contacting Google.

    Legacy stdio retains its existing credential resolution.  Reconfiguring a
    process clears all clients so one identity cannot reuse another's clients.
    """
    global _hosted_auth_enabled, _hosted_service_account_file
    global _hosted_credentials, _hosted_credentials_invalid, _credentials_fingerprint
    global _hosted_file_fingerprint, _hosted_file_valid
    global _searchconsole_service, _webmasters_service, _ga4_data_client, _ga4_admin_client
    with _auth_lock:
        _hosted_auth_enabled = getattr(config, "profile", None) == "production"
        sa_file = getattr(config, "service_account_file", None)
        _hosted_service_account_file = Path(sa_file) if _hosted_auth_enabled and sa_file else None
        _hosted_credentials = None
        _hosted_credentials_invalid = False
        _hosted_file_fingerprint = None
        _hosted_file_valid = False
        _credentials_fingerprint = None
        _searchconsole_service = _webmasters_service = None
        _ga4_data_client = _ga4_admin_client = None


def google_credentials_state() -> str:
    """Offline file/schema availability; never an assertion of Google access.

    Only the configured service-account file is inspected.  No credential
    constructor, token refresh, ADC lookup or OAuth cache creation occurs here.
    """
    if not is_hosted_production() or _hosted_service_account_file is None:
        return "pending"
    try:
        _validate_hosted_service_account_file()
    except FileNotFoundError:
        return "pending"
    except Exception:
        return "invalid"
    return "invalid" if _hosted_credentials_invalid else "available"


def _validate_hosted_service_account_file() -> None:
    """Cache only validation status, never parsed JSON or signing material."""
    global _hosted_file_fingerprint, _hosted_file_valid
    if _hosted_service_account_file is None:
        raise FileNotFoundError
    stat = _hosted_service_account_file.stat()
    fingerprint = (stat.st_dev, stat.st_ino, stat.st_mtime_ns, stat.st_ctime_ns, stat.st_size)
    if fingerprint == _hosted_file_fingerprint:
        if not _hosted_file_valid:
            raise ValueError("invalid service-account file")
        return
    try:
        _read_hosted_service_account_info()
    except Exception:
        _hosted_file_fingerprint, _hosted_file_valid = fingerprint, False
        raise
    _hosted_file_fingerprint, _hosted_file_valid = fingerprint, True


def _read_hosted_service_account_info() -> dict[str, Any]:
    """Bounded local validation, including fixed credential refresh destination.

    This intentionally does not construct Google credentials or validate grants.
    The caller sanitizes every parse/I/O error before it crosses the boundary.
    """
    if _hosted_service_account_file is None:
        raise FileNotFoundError
    if not _hosted_service_account_file.is_file():
        if not _hosted_service_account_file.exists():
            raise FileNotFoundError
        raise ValueError("invalid service-account file")
    with _hosted_service_account_file.open("rb") as source:
        raw = source.read(131073)
    if len(raw) > 131072:
        raise ValueError("invalid service-account file")

    def unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("duplicate service-account field")
            result[key] = value
        return result

    info = json.loads(raw, object_pairs_hook=unique_object)
    if not isinstance(info, dict) or info.get("type") != "service_account":
        raise ValueError("invalid service-account schema")
    email = info.get("client_email")
    key = info.get("private_key")
    if (
        not isinstance(email, str)
        or not email.isascii()
        or not 3 <= len(email) <= 320
        or "@" not in email
        or any(c.isspace() for c in email)
    ):
        raise ValueError("invalid service-account schema")
    if (
        not isinstance(key, str)
        or not key.startswith("-----BEGIN PRIVATE KEY-----\n")
        or not key.rstrip().endswith("-----END PRIVATE KEY-----")
    ):
        raise ValueError("invalid service-account schema")
    if info.get("token_uri") != "https://oauth2.googleapis.com/token":
        raise ValueError("invalid service-account token destination")
    if info.get("universe_domain", "googleapis.com") != "googleapis.com":
        raise ValueError("invalid service-account API destination")
    # Local PEM parsing only: this creates no Google credential/client, token,
    # refresh transport or network request.  Required-credential readiness must
    # reject broken signing data even before a business tool is called.
    RSASigner.from_string(key)
    return info


def _build_hosted_creds() -> Any:
    global _hosted_credentials, _hosted_credentials_invalid
    if _hosted_credentials is not None:
        return _hosted_credentials
    if _hosted_service_account_file is None:
        raise RuntimeError("credentials_missing")
    try:
        _validate_hosted_service_account_file()
        _hosted_credentials = SACredentials.from_service_account_file(
            str(_hosted_service_account_file), scopes=list(SCOPES_READ)
        )
    except FileNotFoundError:
        raise RuntimeError("credentials_missing") from None
    except Exception:
        _hosted_credentials_invalid = True
        raise RuntimeError("credentials_invalid") from None
    _hosted_credentials_invalid = False
    return _hosted_credentials


def _current_credentials_fingerprint() -> str:
    """Hash of the ENV vars + file mtimes that determine which identity wins.

    Cheap to recompute (a couple of stat() calls). Rebuilt on every getter
    call; if it differs from the cached fingerprint, the singletons are
    discarded and built afresh — preventing silent multi-tenant bleed when
    the operator swaps accounts mid-session.
    """
    if is_hosted_production():
        if _hosted_service_account_file is None:
            return "hosted:pending"
        try:
            stat = _hosted_service_account_file.stat()
            version = (
                f"{stat.st_dev}:{stat.st_ino}:{stat.st_mtime_ns}:{stat.st_ctime_ns}:{stat.st_size}"
            )
        except OSError:
            version = "missing"
        return f"hosted:{_hosted_service_account_file}:{version}"
    parts: list[str] = [
        os.getenv("GOOGLE_APPLICATION_CREDENTIALS", ""),
        os.getenv("GOOGLE_SEO_SERVICE_ACCOUNT_FILE", ""),
        os.getenv("GOOGLE_SEO_OAUTH_CLIENT_FILE", ""),
        os.getenv("GOOGLE_PROJECT_ID", ""),
        os.getenv("GSC_ALLOW_DESTRUCTIVE", ""),
    ]
    for path_var in (
        os.getenv("GOOGLE_APPLICATION_CREDENTIALS"),
        os.getenv("GOOGLE_SEO_SERVICE_ACCOUNT_FILE"),
    ):
        if path_var:
            try:
                parts.append(str(Path(path_var).stat().st_mtime_ns))
            except OSError:
                parts.append("missing")
    token_path = _config_dir() / "token.json"
    try:
        parts.append(str(token_path.stat().st_mtime_ns))
    except OSError:
        parts.append("no-token")
    return "|".join(parts)


def _check_fingerprint_or_invalidate() -> None:
    """Rebuild singletons if the underlying credentials sources changed."""
    global _credentials_fingerprint
    fp = _current_credentials_fingerprint()
    if _credentials_fingerprint is None:
        _credentials_fingerprint = fp
        return
    if fp != _credentials_fingerprint:
        log.info(
            "Credentials fingerprint changed (account rotation detected). "
            "Discarding cached clients."
        )
        global _searchconsole_service, _webmasters_service, _ga4_data_client, _ga4_admin_client
        global _hosted_credentials, _hosted_credentials_invalid
        _searchconsole_service = None
        _webmasters_service = None
        _ga4_data_client = None
        _ga4_admin_client = None
        _hosted_credentials = None
        _hosted_credentials_invalid = False
        _credentials_fingerprint = fp


def _config_dir() -> Path:
    p = Path(user_config_dir("google-seo-mcp"))
    p.mkdir(parents=True, exist_ok=True)
    return p


def _scopes() -> list[str]:
    if is_hosted_production():
        return list(SCOPES_READ)
    return SCOPES_WRITE if os.getenv("GSC_ALLOW_DESTRUCTIVE") == "true" else SCOPES_READ


def _from_adc() -> Any | None:
    try:
        creds, project = google_auth_default(scopes=_scopes())
        log.info("Using ADC credentials (project=%s)", project)
        # Validate that the refresh token actually still works against Google.
        # We can't trust `creds.expired` alone: ADC tokens can have a not-yet-
        # expired access token while the underlying refresh token has been
        # silently revoked by Google (security policy, periods of inactivity,
        # cross-machine reuse). The failure then surfaces as a confusing
        # `invalid_grant` 503 inside the first tool call. Force a refresh
        # ALWAYS (one extra ~100ms RPC at startup) to fail fast if the
        # token is dead — and let the cascade fall through to the SA if
        # one is configured.
        try:
            if hasattr(creds, "refresh_token") and creds.refresh_token:
                creds.refresh(Request())
        except RefreshError as e:
            sa_configured = bool(os.getenv("GOOGLE_SEO_SERVICE_ACCOUNT_FILE"))
            if sa_configured:
                log.warning(
                    "ADC refresh failed (%s). GOOGLE_APPLICATION_CREDENTIALS "
                    "is set but the refresh token is revoked or expired. "
                    "Falling through to GOOGLE_SEO_SERVICE_ACCOUNT_FILE. "
                    "TIP: unset GOOGLE_APPLICATION_CREDENTIALS to skip this "
                    "round-trip on every cold start.", e,
                )
                return None
            # No SA fallback — raise an actionable error rather than let
            # the LLM see a raw `invalid_grant` traceback later.
            raise RuntimeError(
                "Google ADC refresh token is revoked or expired.\n"
                "\n"
                "Two options:\n"
                "  (a) RECOMMENDED — Switch to Service Account (no token expiration, "
                "works headless):\n"
                "      1. Create a Service Account JSON in Cloud Console\n"
                "      2. Grant its email Viewer/Restricted on each GSC site + GA4 property\n"
                "      3. export GOOGLE_SEO_SERVICE_ACCOUNT_FILE=/path/to/sa.json\n"
                "      Full walkthrough: README.md § Service Account setup.\n"
                "\n"
                "  (b) Re-run ADC interactively (only works on a desktop with browser):\n"
                "      gcloud auth application-default revoke && \\\n"
                "      gcloud auth application-default login --scopes=...\n"
                "\n"
                "If 'gcloud auth ... login' shows 'This app is blocked', the OAuth client "
                "is unverified for sensitive scopes. Use option (a)."
            ) from e
        return creds
    except RuntimeError:
        raise  # our own actionable message — let it propagate
    except Exception as e:
        log.debug("ADC unavailable: %s", e)
        return None


def _from_service_account() -> Any | None:
    sa_path = os.getenv("GOOGLE_SEO_SERVICE_ACCOUNT_FILE")
    if not sa_path or not Path(sa_path).exists():
        return None
    log.info("Using service account at %s", sa_path)
    return SACredentials.from_service_account_file(sa_path, scopes=_scopes())


def _from_oauth_flow() -> Any | None:
    client_file = os.getenv("GOOGLE_SEO_OAUTH_CLIENT_FILE")
    if not client_file or not Path(client_file).exists():
        return None

    token_path = _config_dir() / "token.json"
    needed_scopes = _scopes()
    creds: Credentials | None = None
    if token_path.exists():
        try:
            creds = Credentials.from_authorized_user_info(
                json.loads(token_path.read_text()), needed_scopes
            )
        except Exception as e:
            log.warning("Could not load cached token, re-authenticating: %s", e)
            creds = None

    # Detect scope upgrade — if the cached token doesn't grant all required scopes
    # (e.g. user just enabled GSC_ALLOW_DESTRUCTIVE which expands `webmasters` scope),
    # discard the cached token and force a fresh consent flow.
    if creds is not None:
        granted = set(getattr(creds, "scopes", None) or [])
        if not set(needed_scopes).issubset(granted):
            log.info(
                "Cached token scopes %s missing required %s — forcing re-auth.",
                granted, set(needed_scopes) - granted,
            )
            creds = None

    if creds and not creds.valid:
        if creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
            except RefreshError as e:
                # Refresh token revoked/rotated — fall through to fresh consent
                # flow rather than letting the exception escape to the LLM.
                log.warning("Refresh failed (%s); will run consent flow.", e)
                creds = None
        else:
            creds = None

    if not creds:
        flow = InstalledAppFlow.from_client_secrets_file(client_file, needed_scopes)
        creds = flow.run_local_server(port=0, open_browser=True)
        # Atomic write — protects against half-written ``token.json`` when two
        # processes / SIGINT race during write.
        _atomic_write_text(token_path, creds.to_json())
        try:
            token_path.chmod(0o600)
        except OSError:  # noqa: PERF203 — chmod can fail on Windows; best-effort.
            pass

    return creds


def _atomic_write_text(target: Path, text: str) -> None:
    """Write text to ``target`` atomically (POSIX + Windows).

    Uses a same-directory tempfile + ``os.replace`` to ensure either the
    old file or the new is observable, never a partial file.
    """
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=target.name + ".", dir=str(target.parent))
    try:
        with os.fdopen(fd, "w") as f:
            f.write(text)
        os.replace(tmp, target)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _build_creds() -> Any:
    if is_hosted_production():
        return _build_hosted_creds()
    creds = _from_adc() or _from_service_account() or _from_oauth_flow()
    if creds is None:
        raise RuntimeError(
            "No Google credentials found. Pick one of three methods:\n"
            "\n"
            "  1) ADC (interactive desktop) — gcloud auth application-default login \\\n"
            "       --scopes=https://www.googleapis.com/auth/webmasters.readonly,"
            "https://www.googleapis.com/auth/analytics.readonly\n"
            "\n"
            "  2) Service Account (RECOMMENDED for headless/agents/multi-client) —\n"
            "       export GOOGLE_SEO_SERVICE_ACCOUNT_FILE=/path/to/sa.json\n"
            "       Then grant the SA email Viewer/Restricted on each GSC site + GA4 property.\n"
            "       Full walkthrough: README.md § Service Account setup.\n"
            "\n"
            "  3) OAuth Desktop flow —\n"
            "       export GOOGLE_SEO_OAUTH_CLIENT_FILE=/path/to/client_secret.json\n"
            "\n"
            "If you already tried ADC and saw 'invalid_grant' or 'This app is blocked', "
            "switch to Service Account. See README.md § Troubleshooting."
        )
    return creds


# ── GSC clients ─────────────────────────────────────────────────────────────

def _hosted_client(factory: Any, *args: Any, **kwargs: Any) -> Any:
    """Do not surface constructor/credential exception values to callers."""
    creds = _build_creds()
    try:
        return factory(*args, credentials=creds, **kwargs)
    except Exception:
        raise RuntimeError("google_client_unavailable") from None

def get_searchconsole():
    """Search Console v1 client (URL Inspection API lives here)."""
    global _searchconsole_service
    if _searchconsole_service is not None and not is_hosted_production():
        return _searchconsole_service
    with _auth_lock:
        _check_fingerprint_or_invalidate()
        if _searchconsole_service is None:
            if is_hosted_production():
                _searchconsole_service = _hosted_client(
                    build, "searchconsole", "v1", cache_discovery=False, static_discovery=True
                )
            else:
                _searchconsole_service = build(
                    "searchconsole", "v1", credentials=_build_creds(), cache_discovery=False
                )
    return _searchconsole_service


def get_webmasters():
    """Webmasters v3 client (Search Analytics, sitemaps, sites)."""
    global _webmasters_service
    if _webmasters_service is not None and not is_hosted_production():
        return _webmasters_service
    with _auth_lock:
        _check_fingerprint_or_invalidate()
        if _webmasters_service is None:
            if is_hosted_production():
                _webmasters_service = _hosted_client(
                    build, "webmasters", "v3", cache_discovery=False, static_discovery=True
                )
            else:
                _webmasters_service = build(
                    "webmasters", "v3", credentials=_build_creds(), cache_discovery=False
                )
    return _webmasters_service


# ── GA4 clients ─────────────────────────────────────────────────────────────

def get_data_client() -> BetaAnalyticsDataClient:
    """GA4 Data API v1beta client (runReport, runRealtimeReport, etc.)."""
    global _ga4_data_client
    if _ga4_data_client is not None and not is_hosted_production():
        return _ga4_data_client
    with _auth_lock:
        _check_fingerprint_or_invalidate()
        if _ga4_data_client is None:
            _ga4_data_client = (
                _hosted_client(BetaAnalyticsDataClient) if is_hosted_production()
                else BetaAnalyticsDataClient(credentials=_build_creds())
            )
    return _ga4_data_client


def get_admin_client() -> AnalyticsAdminServiceClient:
    """GA4 Admin API v1beta client (accounts, properties, custom dims)."""
    global _ga4_admin_client
    if _ga4_admin_client is not None and not is_hosted_production():
        return _ga4_admin_client
    with _auth_lock:
        _check_fingerprint_or_invalidate()
        if _ga4_admin_client is None:
            _ga4_admin_client = (
                _hosted_client(AnalyticsAdminServiceClient) if is_hosted_production()
                else AnalyticsAdminServiceClient(credentials=_build_creds())
            )
    return _ga4_admin_client


# ── Helpers ─────────────────────────────────────────────────────────────────

def current_credential_type() -> str:
    """Returns the credential method that the cascade WOULD pick right now.

    Mirrors the cascade order in `_build_creds()`. Used by the
    `reload_credentials` tool to give a context-specific message
    (Service Account credentials are self-issued and don't need re-auth,
    whereas ADC and OAuth flow can re-trigger a real auth handshake).

    Returns one of: 'service_account', 'adc', 'oauth_flow', 'none'.
    """
    if is_hosted_production():
        return "service_account" if google_credentials_state() == "available" else "none"
    if os.getenv("GOOGLE_APPLICATION_CREDENTIALS") and Path(
        os.environ["GOOGLE_APPLICATION_CREDENTIALS"]
    ).exists():
        # ADC takes precedence over SA in the cascade IF the file exists.
        return "adc"
    sa = os.getenv("GOOGLE_SEO_SERVICE_ACCOUNT_FILE")
    if sa and Path(sa).exists():
        return "service_account"
    oauth = os.getenv("GOOGLE_SEO_OAUTH_CLIENT_FILE")
    if oauth and Path(oauth).exists():
        return "oauth_flow"
    # Default ADC (gcloud's `~/.config/gcloud/application_default_credentials.json`)
    default_adc = Path.home() / ".config" / "gcloud" / "application_default_credentials.json"
    if default_adc.exists():
        return "adc"
    return "none"


def reset_clients(*, drop_oauth_token: bool = True) -> dict:
    """Force rebuild on next access — used by `reload_credentials` tool.

    By default also deletes the cached OAuth `token.json` so that a fresh
    consent flow runs on next use. Pass `drop_oauth_token=False` to keep the
    cached token (useful when you only want to re-read ADC credentials after
    a `gcloud auth application-default login`).

    Returns a dict with `credential_type` (which method the cascade will pick
    on the next call) and a context-specific message that the MCP tool can
    surface to the agent.
    """
    global _searchconsole_service, _webmasters_service, _ga4_data_client, _ga4_admin_client
    global _hosted_credentials, _hosted_credentials_invalid, _credentials_fingerprint
    with _auth_lock:
        _searchconsole_service = None
        _webmasters_service = None
        _ga4_data_client = None
        _ga4_admin_client = None
        _hosted_credentials = None
        _hosted_credentials_invalid = False
        _credentials_fingerprint = None

    if is_hosted_production():
        return {
            "credential_type": current_credential_type(),
            "deleted_oauth_token": False,
            "message": "In-process clients reset; hosted service-account identity retained.",
        }

    cred_type = current_credential_type()
    deleted_token = False

    if drop_oauth_token:
        token_path = _config_dir() / "token.json"
        if token_path.exists():
            try:
                token_path.unlink()
                deleted_token = True
                log.info("Cleared cached OAuth token at %s", token_path)
            except OSError as e:
                log.warning("Could not delete cached token at %s: %s", token_path, e)

    # Build a credential-aware message.
    if cred_type == "service_account":
        message = (
            "In-process clients reset. Active credential: Service Account "
            "(self-issued JWT, no re-auth needed). Next tool call will "
            "reload the SA JSON from disk and rebuild the clients. "
            "Use this if you swapped the SA file or rotated its key."
        )
    elif cred_type == "adc":
        message = (
            "In-process clients reset. Active credential: ADC "
            "(`gcloud auth application-default`). Next tool call will "
            "re-read the ADC file and try a refresh. If the refresh fails "
            "with `invalid_grant`, run `gcloud auth application-default "
            "login --scopes=...` or switch to a Service Account."
        )
    elif cred_type == "oauth_flow":
        if deleted_token:
            message = (
                "In-process clients reset and cached OAuth token deleted. "
                "Next tool call will trigger a fresh consent flow "
                "(opens browser if interactive)."
            )
        else:
            message = (
                "In-process clients reset (OAuth token kept). Next tool "
                "call will reload from cached token.json."
            )
    else:
        message = (
            "In-process clients reset, but NO credentials are configured. "
            "Set one of: GOOGLE_SEO_SERVICE_ACCOUNT_FILE (recommended), "
            "GOOGLE_APPLICATION_CREDENTIALS, GOOGLE_SEO_OAUTH_CLIENT_FILE. "
            "See README.md § Authentication."
        )

    return {
        "credential_type": cred_type,
        "deleted_oauth_token": deleted_token,
        "message": message,
    }


def normalize_property(property_id: int | str) -> str:
    """Accepts int, '123', 'properties/123' and returns canonical 'properties/123'."""
    s = str(property_id).strip()
    if s.startswith("properties/"):
        return s
    if s.isdigit():
        return f"properties/{s}"
    raise ValueError(f"Invalid property_id {property_id!r} — expected int or 'properties/<id>'")
