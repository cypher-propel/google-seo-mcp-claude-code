"""301 redirect mapping plan from old URL set to new URL set.

Uses rapidfuzz (Jaro-Winkler + ratio) for fast slug similarity. Optionally
upgrades to semantic matching if `sentence-transformers` is installed (heavy
dep, ~80MB), but the default rapidfuzz path covers 80% of cases at <1s for
1000 URLs.
"""
from __future__ import annotations

from typing import Any
from urllib.parse import urlparse

from rapidfuzz import fuzz, process


def _slug(url: str) -> str:
    """Path-only, lowercase, no leading/trailing slashes — for similarity matching."""
    p = urlparse(url)
    path = p.path.strip("/").lower()
    # Remove file extensions
    if "." in path.rsplit("/", 1)[-1]:
        path = path.rsplit(".", 1)[0]
    # Replace separators with spaces for fuzz
    return path.replace("-", " ").replace("_", " ").replace("/", " ")


def _path_key(url: str) -> str:
    """Path-only, lowercase, no trailing slash — for O(1) exact lookup."""
    return urlparse(url).path.rstrip("/").lower()


def migration_redirects_plan(
    old_urls: list[str],
    new_urls: list[str],
    min_score: float = 70.0,
) -> dict[str, Any]:
    """Suggest 301 mappings from old_urls → new_urls based on URL similarity.

    Strategy (fastest first):
      1. Exact path match (same slug, different host) — O(1) via dict.
      2. Token-set ratio on slug (catches reorderings, e.g. /blog/x vs /x/blog).
      3. Below `min_score` → no_match (manual review).

    Detects collisions (multiple ``old`` URLs landing on the same ``to``)
    and self-redirects (where ``from == to``) — both are SEO traps that
    earlier versions silently allowed.

    Args:
        min_score: 0-100 fuzz match threshold below which we call no-match.
    """
    if not old_urls or not new_urls:
        return {
            "plan": [],
            "unmatched_old": old_urls,
            "unused_new": new_urls,
            "collisions": [],
            "self_redirects": [],
            "stats": {
                "total_old": len(old_urls), "matched": 0, "exact": 0,
                "fuzzy": 0, "unmatched": len(old_urls),
                "collisions": 0, "self_redirects": 0,
            },
        }

    # Pre-compute slugs and exact-path index for new URLs (O(N) build, O(1) lookup)
    new_slugs = [_slug(n) for n in new_urls]
    slug_to_url = {s: u for s, u in zip(new_slugs, new_urls) if s}
    exact_path_index: dict[str, str] = {}
    for n in new_urls:
        exact_path_index.setdefault(_path_key(n), n)

    plan: list[dict] = []
    unmatched: list[str] = []
    target_to_sources: dict[str, list[str]] = {}
    self_redirects: list[dict] = []

    exact = 0
    fuzzy = 0

    for old in old_urls:
        # 1. Exact path match — O(1)
        old_pk = _path_key(old)
        em = exact_path_index.get(old_pk)
        if em is not None:
            entry = {
                "from": old,
                "to": em,
                "match_type": "exact_path",
                "score": 100.0,
            }
            if old == em:
                # Same URL on both sides — self-redirect would loop.
                self_redirects.append(entry)
            else:
                plan.append(entry)
                target_to_sources.setdefault(em, []).append(old)
                exact += 1
            continue

        # 2. Fuzzy slug match
        old_slug = _slug(old)
        if not old_slug:
            unmatched.append(old)
            continue
        match = process.extractOne(
            old_slug,
            new_slugs,
            scorer=fuzz.token_set_ratio,
            score_cutoff=min_score,
        )
        if match is None:
            unmatched.append(old)
            continue
        # rapidfuzz API: extractOne returns (choice, score, index) on
        # match, None on no-match. Guard against API drift across versions.
        if not isinstance(match, tuple) or len(match) < 3:
            unmatched.append(old)
            continue
        matched_slug, score, idx = match[0], match[1], match[2]
        target = slug_to_url.get(matched_slug, new_urls[idx])
        if old == target:
            self_redirects.append({
                "from": old, "to": target,
                "match_type": "fuzzy_slug", "score": round(score, 1),
            })
            continue
        plan.append({
            "from": old,
            "to": target,
            "match_type": "fuzzy_slug",
            "score": round(score, 1),
        })
        target_to_sources.setdefault(target, []).append(old)
        fuzzy += 1

    # Detect collisions: multiple sources → same target
    collisions = [
        {"target": t, "sources": srcs, "source_count": len(srcs)}
        for t, srcs in target_to_sources.items()
        if len(srcs) > 1
    ]
    collisions.sort(key=lambda c: c["source_count"], reverse=True)

    plan.sort(key=lambda x: x["score"], reverse=True)
    used_new = set(target_to_sources.keys())
    unused_new = [n for n in new_urls if n not in used_new]

    return {
        "plan": plan,
        "unmatched_old": unmatched,
        "unmatched_old_count": len(unmatched),
        "unused_new": unused_new,
        "unused_new_count": len(unused_new),
        "collisions": collisions,
        "self_redirects": self_redirects,
        "stats": {
            "total_old": len(old_urls),
            "total_new": len(new_urls),
            "matched": len(plan),
            "exact": exact,
            "fuzzy": fuzzy,
            "unmatched": len(unmatched),
            "collisions": len(collisions),
            "self_redirects": len(self_redirects),
            "match_rate_pct": round(len(plan) / max(len(old_urls), 1) * 100, 1),
        },
    }


def export_redirects_nginx(plan: list[dict]) -> str:
    """Render a migration plan as Nginx redirect rules (301)."""
    lines: list[str] = ["# Generated by google-seo-mcp migration_redirects_plan"]
    for r in plan:
        old_path = urlparse(r["from"]).path or "/"
        lines.append(f'rewrite ^{old_path}$ {r["to"]} permanent;  # {r["match_type"]} score={r["score"]}')
    return "\n".join(lines)


def export_redirects_apache(plan: list[dict]) -> str:
    """Render a migration plan as Apache .htaccess redirect rules (301)."""
    lines: list[str] = ["# Generated by google-seo-mcp migration_redirects_plan"]
    for r in plan:
        old_path = urlparse(r["from"]).path or "/"
        lines.append(f'Redirect 301 {old_path} {r["to"]}  # {r["match_type"]} score={r["score"]}')
    return "\n".join(lines)


def export_redirects_cloudflare(plan: list[dict]) -> list[dict]:
    """Render a migration plan as Cloudflare Bulk Redirects (Lists API JSON).

    Schema follows the official `wrangler` / Lists API: source_url MUST
    include the scheme, target_url is absolute, and the entry is wrapped
    under a ``redirect`` key. Earlier versions emitted ``netloc + path``
    which the dashboard import rejected.

    Cloudflare Free Lists allow up to 10 000 entries per list; Enterprise
    raises this to 100 000. We expose the count via the wrapper but do
    not split — slicing into multiple Lists is the caller's choice.
    """
    rules: list[dict] = []
    for r in plan:
        # Ensure scheme on source — fall back to https when caller stored
        # netloc-only URLs.
        src = r["from"]
        if not src.startswith(("http://", "https://")):
            src = "https://" + src.lstrip("/")
        rules.append({
            "redirect": {
                "source_url": src,
                "target_url": r["to"],
                "status_code": 301,
                "include_subdomains": False,
                "subpath_matching": False,
                "preserve_query_string": True,
                "preserve_path_suffix": False,
            },
        })
    return rules
